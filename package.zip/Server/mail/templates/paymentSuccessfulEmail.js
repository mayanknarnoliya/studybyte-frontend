exports.paymentSuccessfulEmail = (name, amount, orderId, paymentId) => {
    return `
    <!DOCTYPE html>
        <html>
            <head>
                
            </head>
        </html>
    `
}