import React from 'react'

export const Error = () => {
  return (
    <div className='flex justify-center items-center text-3xl text-blue-300'>
      Error 404: Page Not Found
    </div>
  )
}
